<%
        -- base64解码
        local base_tmp='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/' -- You will need this for encoding/decoding
        local function base64_dec(data)
                data = string.gsub(data, '[^'..base_tmp..'=]', '')
                return (data:gsub('.', function(x)
                if (x == '=') then return '' end
                local r,f='',(base_tmp:find(x)-1)
                for i=6,1,-1 do r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0') end
                return r;
                end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
                if (#x ~= 8) then return '' end
                local c=0
                for i=1,8 do c=c+(x:sub(i,i)=='1' and 2^(8-i) or 0) end
                        return string.char(c)
                end))
        end
        -- URL解码
        local function urlDecode(s)
                s = string.gsub(s, '%%(%x%x)', function(h)
                return string.char(tonumber(h, 16)) end)
                return s
        end

        luci.sys.exec("mkdir /mnt/sda/mi_bak")
        local mac = luci.http.formvalue ("mac")
        if mac=="conf_bak" or mac=="conf_bak_all" then
                local name = urlDecode(base64_dec(luci.http.formvalue ("name")))
                name = string.gsub(name, " ", "")
                name = string.gsub(name, "\r", "")
                name = string.gsub(name, "\n", "")
                if (name == "xxxconf" ) then
                        luci.http.write(luci.sys.exec("cp -rf /data/xxxweb/xxx.json /mnt/sda/mi_bak/xxxconf.xxxbak"))
                else
                        luci.http.write(luci.sys.exec("tar -vcf /mnt/sda/mi_bak/"..name..".xxxbak /data/xxxbox/"..name.." /tmp/xxxbox_tmp/"..name.." /mnt/sda/mi_box/"..name..".tar /mnt/mtd/box/"..name..".tar"))
                end
                luci.http.write(name.." 完成")
                luci.http.close()
        end

        if mac=="conf_rec" or mac=="conf_rec_all" then
                local name = urlDecode(base64_dec(luci.http.formvalue ("name")))
                if (name == "xxxconf" ) then
                        luci.http.write(luci.sys.exec("cp -rf /mnt/sda/mi_bak/xxxconf.xxxbak /data/xxxweb/xxx.json"))
                else
                        luci.http.write(luci.sys.exec("tar -vxf /mnt/sda/mi_bak/"..name..".xxxbak -C /"))
                end
                luci.http.write(name.." 完成")
                luci.http.close()
        end


%>
