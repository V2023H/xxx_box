//aliyundrive
update_aliyundrive=0;query_aliyundrive=0;aliyundrive_up=0;leave_aliyundrive=0;

function checked_qrcode(sid){
    document.getElementById("aliyundrive_text").innerHTML ="正在登录.."
    sid_time++;
    if (checked_qrcode_setInterval==""){document.getElementById("aliyundrive_qr").src=aliyundrive_qr_img_base64;return;}
    if (sid!="" && sid_time>90){document.getElementById("aliyundrive_qr").src="token获取超时！)";return;}
    ajaxPost('<%=REQUEST_URI%>?mac=checked_qrcode_aliyundrive&sid='+sid,{},function(r){
        if (checked_qrcode_setInterval==""){document.getElementById("aliyundrive_qr").src=aliyundrive_qr_img_base64;return;}
            if (r.indexOf('‘前置标记’')) {
                token=r.split('‘前置标记’')[1];
                if (token!=""){
                    if(r!=""){
                        if(r.indexOf("error:")!=-1){return;}
                        clearInterval(checked_qrcode_setInterval);checked_qrcode_setInterval=""
                        document.getElementById("aliyundrive_text").innerHTML ="token:"+token+"登录成功，重启即刻生效"
                        document.getElementById("aliyundrive_qr").src=aliyundrive_qr_img_base64;
                    }
                }else{document.getElementById("aliyundrive_text").innerHTML ="正在登录..."}
            }else{alert("登录数据异常");
                document.getElementById("aliyundrive_qr").src=aliyundrive_qr_img_base64;
                clearInterval(checked_qrcode_setInterval);checked_qrcode_setInterval=""}
        }
    )
}
function up_aliyundrive(str,obj){
    aliyundrive_up=1;
    if (str=="stop_aliyundrive"){
        if (update_aliyundrive==0){
            update_aliyundrive=1;
            ajaxPost('<%=REQUEST_URI%>?mac=stop_aliyundrive', {}, function(r) {
                if (r.indexOf('‘前置标记’')) {alert("停止完成");}else{alert("数据异常");}
                update_aliyundrive=0;aliyundrive_up=0;update_xxx_box("main_setlist");
            })
        }else{alert("目前正在刷新中,请等待...");}
    }
    if (str=="restart_aliyundrive"){
        if (update_aliyundrive==0){
            update_aliyundrive=1;
            ajaxPost('<%=REQUEST_URI%>?mac=restart_aliyundrive', {}, function(r) {
                if (r.indexOf('‘前置标记’')) {alert("重启完成");}else{alert("数据异常");}
                update_aliyundrive=0;aliyundrive_up=0;update_xxx_box("main_setlist");
            })
        }else{alert("目前正在刷新中,请等待...");}
    }
    sid_time=0;checked_qrcode_setInterval="";aliyundrive_qr_img_base64="";
    if (str=="query_aliyundrive"){
        if (query_aliyundrive==0 && checked_qrcode_setInterval==""){
            query_aliyundrive=1;
            ajaxPost('<%=REQUEST_URI%>?mac=query_aliyundrive', {}, function(r) {
                if (r.indexOf('‘前置标记’')) {
                    string=r.split('‘前置标记’')[1];
                    if (string!=""){
                        document.getElementById("aliyundrive_text").innerHTML ="正在登录."
                        aliyundrive_json=JSON.parse(string);
                        if(aliyundrive_qr_img_base64==""){aliyundrive_qr_img_base64=document.getElementById("aliyundrive_qr").src}
                        document.getElementById("aliyundrive_qr").src=aliyundrive_json["qrCodeUrl"];
                        sid_time=0;
                        checked_qrcode_setInterval=setInterval("checked_qrcode('"+aliyundrive_json["sid"]+"')",2000);
                    }else{alert("数据异常1");}
                }else{alert("数据异常2");}
                query_aliyundrive=0;aliyundrive_up=0;
            })
        }else{alert("目前正在操作中,请等待...");}
    }
}
