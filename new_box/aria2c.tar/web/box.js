    update=0;
    function aria2c_butt_click(obj){
        if (update==0){
            update=1;
            if (obj.value=="保存"){
                pass=obj.parentNode['aria2c_box_pass'].value
                ajaxPost('<%=REQUEST_URI%>?mac=aria2c_update&pass='+btoa(encodeURIComponent(pass)), {}, function(r) {
                    alert(r);
                    update=0;
                })
            }else if(obj.value=="重启"){
                ajaxPost('<%=REQUEST_URI%>?mac=aria2c_start', {},function(r){
                    alert(r);update_xxx_box("main_setlist");
                    update=0;
                })
            }
        }else{alert("繁忙中,请等待...");}
    }
