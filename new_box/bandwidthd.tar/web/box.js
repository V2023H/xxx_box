function bandwidthd_upwebui(main_id){
	update_xxx_box("main_setlist");
}
