#!/bin/sh
file_path=$(dirname $0)
file_name="disktest"
cd $file_path && source /etc/profile >/dev/null
#准备启动必需文件
mkdir /tmp/xxxbox_tmp/$file_name > /dev/null 2>&1

#文件提权
chmod 777 $xxx_path/xxxbox/$file_name -R
chown root:root $xxx_path/xxxbox/$file_name -R > /dev/null 2>&1

#定义位置
if [ -n "$1" ]; then
    [ -d "$1" ] || echo 位置 $1 空间未确认！
    [ -d "$1" ] || exit
    diskpath=$1
    disksize=`df $1 | sed -n '2p' | awk '{print $4}'`
    [ $disksize -lt 2000000 ] && echo 位置$diskpath 空间不足以测速 || echo 位置$diskpath 开始测速...
    [ $disksize -lt 2000000 ] && exit
else
    echo 未定义位置，准备开始...
    exit
    diskpath=`df | grep /dev/sd | sed -n '1p' | awk '{print $6}'`
    disksize=`df | grep /dev/sd | sed -n '1p' | awk '{print $4}'`
    [ $disksize -lt 2000000 ] && echo 位置$diskpath 空间不足以测速 || echo 位置$diskpath 开始测速...
    if [ $disksize -lt 2000000 ]; then
        diskpath=`df | grep /dev/sd | sed -n '2p' | awk '{print $6}'`
        disksize=`df | grep /dev/sd | sed -n '2p' | awk '{print $4}'`
        [ $disksize -lt 2000000 ] && echo 位置$diskpath 空间不足以测速 || echo 位置$diskpath 开始测速...
        [ $disksize -lt 2000000 ] && exit
    fi
fi
cd $diskpath

#读写测试
touch diskpath_test
[ -f $diskpath"/diskpath_test" ] || echo 空间未确认！
[ -f $diskpath"/diskpath_test" ] || exit
rm -rf diskpath_test

#开始测速
rm -f ./largefile > /dev/null 2>&1
dd if=/dev/zero of=./largefile bs=1M count=500 2> ./disk_tmp
echo 写入速度: $(cat disk_tmp | grep /s | awk '{print $7}')
echo 3 | tee /proc/sys/vm/drop_caches >/dev/null
dd if=./largefile of=/dev/null bs=4M 2> ./disk_tmp
echo 读取速度: $(cat disk_tmp | grep /s | awk '{print $7}')
rm -rf ./largefile
rm -rf ./disk_tmp
