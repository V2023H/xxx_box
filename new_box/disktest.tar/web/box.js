function up_disktest_shell(){
    document.getElementById("disktest_shell_box").style="height: 150px;margin-bottom: 20px;"
    document.getElementById("disktest_shell_iframe").style="height: 150px;margin-bottom: 20px;"
}
function start_disktest(obj){
    disktest_sel=document.getElementById("disktest_sel")
    document.getElementById('disktest_shell_iframe').src = "http://"+document.domain+":37682/?arg="+disktest_sel.options[disktest_sel.selectedIndex].innerText;
    up_disktest_shell();
}
