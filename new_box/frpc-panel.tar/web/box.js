//frpc_panel
update_frpc_panel=0;frpc_panel_up=0;
function up_frpc_panel(obj){
    frpc_panel_up=1;
    if (update_frpc_panel==0){
        update_frpc_panel=1;
        ajaxPost('<%=REQUEST_URI%>?mac='+obj.id+"&frpc_panel_text=" +btoa(encodeURIComponent(document.getElementById("frpc_panel_text").value)), {}, function(r) {
            if (r.indexOf('前置标记')) {alert("完成");}else{alert("数据异常");}
            update_frpc_panel=0;frpc_panel_up=0;update_xxx_box("main_setlist");
        })
    }else{alert("目前正在刷新中,请等待...");}
}
