//frps_panel
update_frps_panel=0;frps_panel_up=0;
function up_frps_panel(obj){
    frps_panel_up=1;
    if (update_frps_panel==0){
        update_frps_panel=1;
        ajaxPost('<%=REQUEST_URI%>?mac='+obj.id+"&frps_panel_text=" +btoa(encodeURIComponent(document.getElementById("frps_panel_text").value)), {}, function(r) {
            if (r.indexOf('前置标记')) {alert("完成");}else{alert("数据异常");}
            update_frps_panel=0;frps_panel_up=0;update_xxx_box("main_setlist");
        })
    }else{alert("目前正在刷新中,请等待...");}
}
