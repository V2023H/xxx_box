#!/bin/sh
file_path=$(dirname $0)
file_name="iperf3client"
cd $file_path && source /etc/profile >/dev/null
#准备启动必需文件
mkdir /tmp/xxxbox_tmp/$file_name > /dev/null 2>&1
chmod 777 $xxx_path/xxxbox/$file_name/$file_name
cd $file_path
#状态检查，状态调整
chmod 777 $xxx_path/xxxbox/iperf3client/$file_name
[ -n "$1" ] || echo 没有ip不能测速！！
[ -n "$1" ] || exit
IP=$1
VALID_CHECK=$(echo $IP|awk -F. '$1<=255&&$2<=255&&$3<=255&&$4<=255{print "yes"}')
if echo $IP|grep -E "^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$">/dev/null; then
    if [ ${VALID_CHECK:-no} == "yes" ]; then
        $xxx_path/xxxbox/iperf3client/iperf3client -c $1
    else
        echo "$IP 非正常IP，请检查一下!"
    fi
else
    echo "IP 格式错误"
fi
