function up_iperf3client_shell(){
    document.getElementById("iperf3client_shell_box").style="height: 150px;margin-bottom: 20px;"
    document.getElementById("iperf3client_shell_iframe").style="height: 150px;margin-bottom: 20px;"
}

function start_iperf3client(obj){
    iperf3client_ip=document.getElementById("iperf3client_ip")
    document.getElementById('iperf3client_shell_iframe').src = "http://"+document.domain+":38682/?arg="+iperf3client_ip.value;
    up_iperf3client_shell();
}
