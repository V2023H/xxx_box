<%
-- 开启ttyd
luci.sys.exec("source /etc/profile && sh -c \"/tmp/xxxbox_tmp/xxx_ttyd -u 62389 -W -a -p 38682 $(uci get lyq.xxx_path)/xxxbox/iperf3client/test.sh\" > /dev/null 2>&1 &")
%>
