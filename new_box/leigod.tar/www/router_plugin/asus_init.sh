#!/bin/sh

# get param 
ACTION=$1

# define 
ver_name="version"
init_file_name="acc"
binary_prefix="acc-gw.linux"
common_file_name="plugin_common.sh"
uninstall_file_name="leigod_uninstall.sh"
download_base_url="http://119.3.40.126/router_plugin"

# get_device_arch, 
# current support arch: arm64 arm x86_64 mips 
get_device_arch() {
  arch=$(uname -m)
  if [ $? != "0" ]; then
    echo "arch cant be get"
    return -1
  fi
  # fix arch 
  if [ ${arch} == "x86_64" ]; then
    echo "match x86_64 -> amd64"
    arch="amd64"
  elif [ ${arch} == "aarch64" ]; then
    echo "match aarch64 -> arm64"
    arch="arm64"
  elif [ ${arch} == "mips" ]; then
    echo "match mips -> mipsle"
    arch="mipsle"
  elif [ ${arch} == "armv7l" ]; then
    arch="arm"
  fi
  return 0
}

# get_asus_name get asus name
get_merlin_party() {
  if [[ -d "/koolshare" ]]; then
    echo "router is merlin series, name: $(nvram get build_name)"
    nvram set 3rd-party=merlin
    is_merlin=true
    sbin_dir="/koolshare/leigod/acc"
    init_dir="/koolshare/init.d"
    echo "message"
    return 0
  elif [[ -d "/jffs/softcenter" ]]; then
    echo "router is swrt series, name: $(nvram get build_name)"
    is_swrt=true
    nvram set 3rd-party=swrt
    sbin_dir="/jffs/softcenter/leigod/acc"
    init_dir="/jffs/softcenter/init.d"
    return 0
  fi
  # check merlin
  echo "route is not merlin, use general asus"
  return 0
}

# prepare
get_device_arch
get_merlin_party

echo "sbin: ${sbin_dir}"
. ${sbin_dir}/${common_file_name}

case ${ACTION} in
  "start")
    nohup_cmd=$(which nohup)
    cmd="${nohup_cmd} ${sbin_dir}/${binary_prefix}.${arch}"
    echo "sbin now: ${sbin_dir}, bin prefix: ${binary_prefix}, arch: ${arch}"
    echo "start service: ${cmd}"
    ${cmd} &
    sleep 2s
    ;;
  "stop")
esac
