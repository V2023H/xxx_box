#!/bin/sh


# monitor leigod acc state
echo "begin to check leigod app status..."

# process path
exec_path="/userdisk/appdata/leigod"
exec_cmd="--mode tun"
# appname prefix
appname_prefix="acc-gw.linux"
# init dir
init_dir="/etc/init.d"
acc_file="acc"

# get_device_arch, 
# current support arch: arm64 arm x86_64 mips 
get_device_arch() {
  arch=$(uname -m)
  if [ $? != "0" ]; then
    echo "arch cant be get"
    return -1
  fi
  # fix arch 
  if [ ${arch} == "x86_64" ]; then
    echo "match x86_64 -> amd64"
    arch="amd64"
  elif [ ${arch} == "aarch64" ]; then
    echo "match aarch64 -> arm64"
    arch="arm64"
  elif [ ${arch} == "mips" ]; then
    echo "match mips -> mipsle"
    arch="mipsle"
  fi
  return 0
}

get_device_arch
# define app name 
appname=${appname_prefix}.${arch}

# prepare env
echo "check env, arch: " ${arch}", appname: "${appname}

# check if acc exist
count=`ps | grep -w ${appname} | wc -l`

start_proc ()
{
  # start acc
  ${exec_path}/${acc_file} start
}

echo "count is: "${count}

# exist state
if [ ${count} == 1 ]; then
  echo "leigod accelerator cant found, restart..."
  start_proc
else
  echo "leigod accelerator already in use..."
fi
