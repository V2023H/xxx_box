//npc
update_npc=0;npc_up=0;
function up_npc(obj){
    npc_up=1;
    if (update_npc==0){
        update_npc=1;
        ajaxPost('<%=REQUEST_URI%>?mac='+obj.id+"&npc_text=" +btoa(encodeURIComponent(document.getElementById("npc_text").value)), {}, function(r) {
            if (r.indexOf('前置标记')) {alert("完成");}else{alert("数据异常");}
            update_npc=0;npc_up=0;update_xxx_box("main_setlist");
        })
    }else{alert("目前正在刷新中,请等待...");}
}
