//nps
update_nps=0;nps_up=0;
function up_nps(obj){
    nps_up=1;
    if (update_nps==0){
        update_nps=1;
        ajaxPost('<%=REQUEST_URI%>?mac='+obj.id+"&nps_text=" +btoa(encodeURIComponent(document.getElementById("nps_text").value)), {}, function(r) {
            if (r.indexOf('前置标记')) {alert("完成");}else{alert("数据异常");}
            update_nps=0;nps_up=0;update_xxx_box("main_setlist");
        })
    }else{alert("目前正在刷新中,请等待...");}
}
