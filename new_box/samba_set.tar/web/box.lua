<%
        -- base64解码
        local base_tmp='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/' -- You will need this for encoding/decoding
        local function base64_dec(data)
                data = string.gsub(data, '[^'..base_tmp..'=]', '')
                return (data:gsub('.', function(x)
                if (x == '=') then return '' end
                local r,f='',(base_tmp:find(x)-1)
                for i=6,1,-1 do r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0') end
                return r;
                end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
                if (#x ~= 8) then return '' end
                local c=0
                for i=1,8 do c=c+(x:sub(i,i)=='1' and 2^(8-i) or 0) end
                        return string.char(c)
                end))
        end
        -- URL解码
        local function urlDecode(s)
                s = string.gsub(s, '%%(%x%x)', function(h)
                return string.char(tonumber(h, 16)) end)
                return s
        end

        local mac = luci.http.formvalue ("mac")
        if mac=="samba_update" then
                local pass = urlDecode(base64_dec(luci.http.formvalue ("pass")))
                if pass~="" then luci.sys.exec("printf '"..pass.."\\n"..pass.."' | smbpasswd -a -s root") end
                luci.http.write("完成")
                luci.http.close()
        end


        if mac=="samba_start" then
                luci.sys.exec("/etc/init.d/samba restart")
                luci.http.write("完成")
                luci.http.close()
        end

%>
