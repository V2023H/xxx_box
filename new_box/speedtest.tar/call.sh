file_path=$(dirname $0)
file_name="speedtest"
cd $file_path && source /etc/profile >/dev/null
#准备启动必需文件
mkdir /tmp/xxxbox_tmp/$file_name > /dev/null 2>&1
ln -sf /tmp/xxxbox_tmp/$file_name/$file_name $xxx_path/xxxbox/$file_name/$file_name

#文件提权
chmod 777 $xxx_path/xxxbox/$file_name -R
chmod 777 /tmp/xxxbox_tmp/$file_name -R
chown root:root $xxx_path/xxxbox/$file_name -R > /dev/null 2>&1
chown root:root /tmp/xxxbox_tmp/$file_name -R > /dev/null 2>&1

echo -e "- 测试网速工具"
echo -e "1.开始测试网速"
echo -e "2.选择测试服务器"
read -p "请选择 > " num
case $num in
1)
    echo 开始测速...
    $xxx_path/xxxbox/speedtest/speedtest
;;
2)
    echo 选择服务器...
    $xxx_path/xxxbox/speedtest/speedtest -L
    read -p "请输入服务器ID > " speedtest_s
    $xxx_path/xxxbox/speedtest/speedtest -s $speedtest_s
    $0
;;
esac

