//test
test_code=0;
function test_call(id){
    if (test_code==0){
        test_code=1;
        test_form=document.getElementById("test_form")
        test_time=test_form["test_time"].value
        ajaxPost('<%=REQUEST_URI%>?mac='+id+"&test_time="+btoa(test_time), {}, function(res) {
            res=JSON.parse(res);
            test_code=res["code"];
            if (res["code"]==0) {
                if (id=="test_start"){test_start(res["test_time"])}
                if (id=="test_save"){alert(res["info"]);}
            }else{alert("错误");}
        })
    }else{alert("正在运行中,请等待...");}
}
interval_time=0;interval_code=0;
function test_start(test_time){
    if (interval_code==1) {alert("正在运行中,请等待...");return;}
    interval_time=0;interval_code=1;test_upwebui("test_box");
    interval = window.setInterval("interval_func("+test_time+")","1000");
}
function interval_func(time){
    interval_time++;
    document.getElementById("interval_time").innerHTML=(time-interval_time==0?"停止":(time-interval_time)+" 秒");
    if (time-interval_time == 0) {window.clearInterval(interval);interval_code=0;test_upwebui("test_box");}
}
function test_upwebui(main_id){
	update_xxx_box("main_setlist");
}
