<%
    local mac = luci.http.formvalue("mac")
    local test_time = luci.http.formvalue("test_time")
    luci.sys.exec("chmod 777 $(uci get lyq.xxx_path)/xxxbox/test/web/box.sh")
    if mac=="test_save" then
        local rstr=luci.sys.exec("sh $(uci get lyq.xxx_path)/xxxbox/test/web/box.sh set_prm "..test_time)
        rstr = string.gsub(rstr, "\n", "")
        rstr='{"code":"0","info":"'..rstr..'"}'
        luci.http.write(rstr)
        luci.http.close()
    end

    if mac=="test_start" then
        local test_time=luci.sys.exec("echo -n $(source  $(uci get lyq.xxx_path)/xxxbox/test/call > /dev/null && echo $prm)")
        test_time = string.gsub(test_time, "\n", "")
        local rstr = luci.sys.exec("sh $(uci get lyq.xxx_path)/xxxbox/test/web/box.sh start")
        rstr='{"code":"0","test_time":"'..test_time..'","info":"开始运行"}'
        luci.http.write(rstr)
        luci.http.close()
    end
%>
