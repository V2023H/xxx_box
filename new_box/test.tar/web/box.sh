[ "$1" = 'set_prm' ] && $(uci get lyq.xxx_path)/xxxcon/xxxapi test set_prm $2
[ "$1" = 'start' ] && $(uci get lyq.xxx_path)/xxxbox/test/call start
