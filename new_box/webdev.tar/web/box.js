    update=0;
    function webdev_butt_click(obj){
        if (update==0){
            update=1;
            if (obj.value=="保存"){
                user=obj.parentNode['webdev_box_user'].value
                pass=obj.parentNode['webdev_box_pass'].value
                ajaxPost('<%=REQUEST_URI%>?mac=webdev_update&pass='+btoa(encodeURIComponent(pass))+'&user='+btoa(encodeURIComponent(user)), {}, function(r) {
                    alert(r);
                    update=0;
                })
            }else if(obj.value=="重启"){
                ajaxPost('<%=REQUEST_URI%>?mac=webdev_start', {},function(r){
                    alert(r);update_xxx_box("main_setlist");
                    update=0;
                })
            }
        }else{alert("繁忙中,请等待...");}
    }
