<%
        -- base64解码
        local base_tmp='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/' -- You will need this for encoding/decoding
        local function base64_dec(data)
                data = string.gsub(data, '[^'..base_tmp..'=]', '')
                return (data:gsub('.', function(x)
                if (x == '=') then return '' end
                local r,f='',(base_tmp:find(x)-1)
                for i=6,1,-1 do r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0') end
                return r;
                end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
                if (#x ~= 8) then return '' end
                local c=0
                for i=1,8 do c=c+(x:sub(i,i)=='1' and 2^(8-i) or 0) end
                        return string.char(c)
                end))
        end
        -- URL解码
        local function urlDecode(s)
                s = string.gsub(s, '%%(%x%x)', function(h)
                return string.char(tonumber(h, 16)) end)
                return s
        end

        local mac = luci.http.formvalue ("mac")
        if mac=="webdev_update" then
                local user = urlDecode(base64_dec(luci.http.formvalue ("user")))
                local pass = urlDecode(base64_dec(luci.http.formvalue ("pass")))
                if user~="" then luci.sys.exec("uci set lyq.webdev_username='"..user.."'") end
                if pass~="" then luci.sys.exec("uci set lyq.webdev_password='"..pass.."'") end
                luci.sys.exec("echo $(uci get lyq.webdev_username):$(uci get lyq.webdev_password)>$(uci get lyq.xxx_path)/xxxbox/webdev/conf/lighttpd/lighttpd.user")
                luci.http.write("完成")
                luci.http.close()
        end

        if mac=="webdev_start" then
                luci.http.write(luci.sys.exec("$(uci get lyq.xxx_path)/xxxcon/xxxbox webdev restart"))
                luci.http.close()
        end

%>
