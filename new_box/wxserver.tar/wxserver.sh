cd  `dirname $0`
. ./wxserver.conf
if [ "$1" == "get" ]; then
    [ `eval echo $"$2"` = "1" ] && echo on || echo off
    exit
fi
if [ "$1" == "set" ]; then
    [ `eval echo $"$2"` = "1" ] && sed -i 's/'$2'=1/'$2'=0/g' wxserver.conf || sed -i 's/'$2'=0/'$2'=1/g' wxserver.conf
    [ `eval echo $"$2"` = "1" ] && echo 已关闭 || echo 已开启
    exit
fi
rm -f /tmp/tmp/sxtx
echo 0.0.0.0 > /tmp/tmp/iptx
touch /tmp/tmp/sxtx
n=0 #计时
while [ "$onof" = "1" ] && [ "$token" != "" ];
do
    . ./wxserver.conf
    #token=使用时请忽略此行
    #开机提醒 卡机提醒1次
    if [ "$kjtx" = "1" ] && [ "$onof" = "1" ] ; then
        if [ ! -n "$(ls /tmp/tmp | grep 'kjtx')" ] ; then
            tmp=开机提醒设备"`uci get xiaoqiang.common.ROUTER_NAME`"
            logger $(date "+%Y-%m-%d %H:%M:%S")_微信推送："$tmp"
            url=https://api.letserver.run/message/auto?token="$token"\&msg="$tmp"
            curl $url -k
            touch /tmp/tmp/kjtx
        fi
    fi

    #上下线提醒 间隔3秒一次
    if [ "$onof" = "1" ] ; then
        dhcp=''
        dev_json_list=`ubus call trafficd hw`
        dev_mac_list=`echo "$dev_json_list"| jsonfilter -e "@[*]['hw']"`
        var=${dev_mac_list//\n/ }
        for ele in $var
        do
            ot=`echo "$dev_json_list" | jsonfilter -e "@['"$ele"']['online_timer']"`
            echo "$ot" | [ ! -n "`sed -n '/^[0-9][0-9]*$/p'`" ] && ot=-1
            if [ "$ot" -gt "0" ]; then
                dhcp=$dhcp`echo "$dev_json_list" | jsonfilter -e "@['"$ele"']['hw']"`".on"\\n
            else
                dhcp=$dhcp`echo "$dev_json_list" | jsonfilter -e "@['"$ele"']['hw']"`".off"\\n
            fi
        done
        dhcp=`echo -e "$dhcp"`
        #cy=`echo "$(awk '{print $0}' /tmp/dhcp.sxtx /tmp/tmp/sxtx |sort|uniq -u)"`
        all=`echo -e "$dhcp"`\\n`cat /tmp/tmp/sxtx`
        all=`echo -e "$all"`
        #echo "$all"
        echo -e "$dhcp" > /tmp/tmp/sxtx
        cy=`echo "$(echo "$all"|sort|uniq -u)"`
        cy=`echo "${cy//.on/}"`
        cy=`echo "${cy//.off/}"`
        cy=`echo "$(echo "$cy"|sort|uniq)"`
        if [ "$cy" != '' ] ; then
            if [ "$xxtx" = "1" ] ; then
                for line in $cy
                do
                    tmp_mac=`echo "$dhcp" | grep $line | grep .off | sed  "s/.off//g"`
                    if [ "$tmp_mac" != "" ] && [ -n "$(echo -e $tmp_mac | grep -o -E '([[:xdigit:]]{1,2}:){5}[[:xdigit:]]{1,2}')" ]; then
                        tmp_name=`echo "$dev_json_list"| jsonfilter -e "@['$tmp_mac']['hostname']"`
                        if [ $tmp_name != "" ] && [ $n != "0" ] ; then
                            tmp=设备提醒"$tmp_name"离开`uci get xiaoqiang.common.ROUTER_NAME`
                            logger $(date "+%Y-%m-%d %H:%M:%S")_微信推送："$tmp"
                            url=https://api.letserver.run/message/auto?token="$token"\&msg="$tmp"
                            curl $url -k >/dev/null 2>&1 &
                        fi
                    fi
                    #name=`echo -e "$all" | grep $line | awk '{print $0}' | sed -n '1p'`
                    #name=`eval echo $name`
                done
            fi
            if [ "$sxtx" = "1" ] ; then
                for line in $cy
                do
                    tmp_mac=`echo "$dhcp" | grep $line | grep .on | sed  "s/.on//g"`
                    if [ "$tmp_mac" != "" ] && [ -n "$(echo -e $tmp_mac | grep -o -E '([[:xdigit:]]{1,2}:){5}[[:xdigit:]]{1,2}')" ]; then
                        if [ $tmp_name != "" ] && [ $n != "0" ] ; then
                            tmp_name=`echo "$dev_json_list"| jsonfilter -e "@['$tmp_mac']['hostname']"`
                            tmp_ifname=`echo "$dev_json_list"| jsonfilter -e "@['$tmp_mac']['ifname']"`
                            tmp_ifname=`iwinfo $tmp_ifname info | grep ESSID`
                            tmp_ifname=`eval echo $tmp_ifname`
                            tmp_ifname=${tmp_ifname#*:}
                            tmp=设备提醒"$tmp_name"加入"`uci get xiaoqiang.common.ROUTER_NAME`"
                            logger $(date "+%Y-%m-%d %H:%M:%S")_微信推送：$(date "+%Y-%m-%d %H:%M:%S")"$tmp"
                            url=https://api.letserver.run/message/auto?token="$token"\&msg="$tmp"
                            curl $url -k >/dev/null 2>&1 &
                        fi
                    fi
                done
            fi
        fi
    fi

    #ip变化提醒 间隔60秒一次
    if [ "$iptx" = "1" ] && [ $(($n%20)) = "0" ] && [ "$onof" = "1" ] ; then
        arIpAddress() {
        curltest=`which curl`
        if [ -z "$curltest" ] || [ ! -s "`which curl`" ] ; then
            wget -T 5 -t 3 --user-agent "$user_agent" --quiet --output-document=- "ip.3322.net" | grep -E -o '([0-9]+\.){3}[0-9]+' | head -n1 | cut -d' ' -f1
        else
            curl -L --user-agent "$user_agent" -s ip.3322.net | grep -E -o '([0-9]+\.){3}[0-9]+' | head -n1 | cut -d' ' -f1
        fi
        }
        hostIP=$(arIpAddress)
        if ! echo ${hostIP} | grep -o '[0-9]\{1,3\}\.[0-9]\{1,3\}.[0-9]\{1,3\}\.[0-9]\{1,3\}' &> /dev/null;then
            echo "ERROR:ip${ip}不合法,网络连接异常！！"
        else
            if [ $(cat /tmp/tmp/iptx) != $hostIP ] && [ $n != "0" ] ; then
                tmp=IP变化`uci get xiaoqiang.common.ROUTER_NAME`提醒,新："$hostIP"
                logger $(date "+%Y-%m-%d %H:%M:%S")_微信推送：$(date "+%Y-%m-%d %H:%M:%S")"$tmp"
                url=https://api.letserver.run/message/auto?token="$token"\&msg="$tmp"
                curl $url -k
            fi
            echo $hostIP > /tmp/tmp/iptx
        fi
    fi
n=$(($n+1))
sleep 3
done
