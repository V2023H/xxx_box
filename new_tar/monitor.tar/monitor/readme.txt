状态监控插件（参考 ROG 工具箱）

功能：
- 实时显示 CPU 温度（四核取最大）
- 网卡温度（2.4G / 5G / 5G高，通过 thermaltool）
- CPU 各核主频
- 系统负载、内存、内核版本、架构、运行时间
- 历史温度日志（可配置采样间隔，默认300秒）

安装：
打包为 tar.xz 后，在 xxx_box 软件中心上传安装，
或放入插件安装目录。

路径约定：
- 安装位置：$(uci get lyq.xxx_path)/xxxbox/monitor/
- 日志文件：monitor/tmp/data.log

操作：
- 启动/停止：软件中心界面按钮，或
  sh call start / sh call stop
- 修改采样间隔：界面输入秒数点保存

文件说明：
- call        启动控制脚本
- monitor     监控主程序（循环采集）
- web/        UI 页面（box.htm/js/css/lua/sh）
