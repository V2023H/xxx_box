/*
<name>监控</name>
<version>7</version>
*/
var monitor_interval = 0;
function monitor_box_shown() {
    var el = document.getElementById("monitor_data");
    if (!el) { return false; }
    return el.getClientRects().length > 0;
}
function monitor_refresh() {
    if (!monitor_box_shown()) { return; }
    ajaxPost('<%=REQUEST_URI%>?mac=monitor_data', {}, function(res) {
        try {
            var json = null;
            var m = res.match(/\{[\s\S]*\}/);
            if (m) { json = JSON.parse(m[0]); }
            if (json && json["code"] == 0) {
                var el = document.getElementById("monitor_data");
                if (el) { el.innerHTML = monitor_html(json); }
            }
        } catch (e) { console.log("monitor parse error: " + e); }
    });
}
function monitor_html(res) {
    var h = '';
    h += '<div class="m-row"><span>更新时间</span><span class="m-val">' + res["time"] + '</span></div>';
    h += '<div class="m-row"><span>CPU 温度</span><span class="m-val">' + res["cpu_temp"] + '°C</span></div>';
    h += '<div class="m-row"><span>网卡温度</span><span class="m-val">' + res["wifi"] + '</span></div>';
    h += '<div class="m-row"><span>风扇</span><span class="m-val">' + res["fan"] + ' RPM</span></div>';
    h += '<div class="m-row"><span>WAN口温度</span><span class="m-val">' + res["phy_temp"] + '°C</span></div>';
    h += '<div class="m-row"><span>CPU 主频</span><span class="m-val">' + res["mhz"] + '</span></div>';
    h += '<div class="m-row"><span>系统负载</span><span class="m-val">' + res["load"] + '</span></div>';
    h += '<div class="m-row"><span>内存</span><span class="m-val">' + res["mem"] + '</span></div>';
    h += '<div class="m-row"><span>内核版本</span><span class="m-val">' + res["kernel"] + '</span></div>';
    h += '<div class="m-row"><span>架构</span><span class="m-val">' + res["arch"] + '</span></div>';
    h += '<div class="m-row"><span>开机时长</span><span class="m-val">' + res["boot"] + '</span></div>';
    h += '<div class="m-row"><span>编译时间</span><span class="m-val">' + res["build"] + '</span></div>';
    return h;
}
function monitor_init() {
    if (monitor_interval) { window.clearInterval(monitor_interval); }
    monitor_interval = window.setInterval(monitor_refresh, 10000);
    monitor_refresh();
}
monitor_init();