<%
    local mac = luci.http.formvalue("mac")
    luci.sys.exec("chmod 777 $(uci get lyq.xxx_path)/xxxbox/monitor/web/box.sh 2>/dev/null")
    if mac=="monitor_data" then
        local rstr = luci.sys.exec("sh $(uci get lyq.xxx_path)/xxxbox/monitor/web/box.sh data")
        rstr = string.gsub(rstr, "\n", "")
        luci.http.write(rstr)
        luci.http.close()
    end
%>