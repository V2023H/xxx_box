[ "$1" = 'data' ] && {
    cpu_temp=0
    for z in 7 8 9 10; do
        [ -f /sys/class/thermal/thermal_zone$z/temp ] || continue
        v=$(cat /sys/class/thermal/thermal_zone$z/temp 2>/dev/null)
        [ -z "$v" ] && continue
        v=$((v / 1000))
        [ $v -gt $cpu_temp ] && cpu_temp=$v
    done
    [ $cpu_temp -eq 0 ] && cpu_temp=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null)
    [ $cpu_temp -gt 1000 ] && cpu_temp=$((cpu_temp / 1000))

    wifi=""
    for i in wifi0 wifi1 wifi2; do
        t=$(thermaltool -i $i -get 2>/dev/null | grep "sensor temperature" | sed 's/.*temperature: \([0-9][0-9]*\).*/\1/')
        [ -z "$t" ] && t="off"
        case $i in
            wifi0) wifi="$wifi 2.4G:${t}°C" ;;
            wifi1) wifi="$wifi 5G:${t}°C" ;;
            wifi2) wifi="$wifi 5G Game:${t}°C" ;;
        esac
    done

    mhz=""
    m=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq 2>/dev/null)
    [ -n "$m" ] && mhz="$((m / 1000))MHz" || mhz="?"

    fan_rpm=$(cat /sys/devices/platform/soc/78b8000.i2c/i2c-1/1-002f/fan1_input 2>/dev/null)
    [ -z "$fan_rpm" ] && fan_rpm="off"
    fan_pwm=$(cat /sys/class/hwmon/hwmon2/pwm1 2>/dev/null)
    [ -z "$fan_pwm" ] && fan_pwm=0
    fan_pct=$((fan_pwm * 100 / 255))

    phy_temp=$(cat /sys/class/hwmon/hwmon0/temp1_input 2>/dev/null)
    [ -n "$phy_temp" ] && phy_temp=$((phy_temp / 1000))

    load=$(cat /proc/loadavg 2>/dev/null | awk '{print $1"/"$2"/"$3}')
    mem_total=$(awk '/MemTotal/{printf "%d", $2/1024}' /proc/meminfo 2>/dev/null)
    mem_used=$(awk '/MemTotal/{t=$2} /MemAvailable/{a=$2} END{printf "%d", (t-a)/1024}' /proc/meminfo 2>/dev/null)
    mem="${mem_used}MB/${mem_total}MB"; [ -z "$mem_used" ] && mem="-"
    kernel=$(uname -r)
    arch=$(uname -m)
    bd_upt=$(awk '{printf "%d %d %d %d", int($1/86400), int($1%86400/3600), int($1%3600/60), int($1%60)}' /proc/uptime 2>/dev/null)
    bd_d2=$(echo "$bd_upt" | awk '{print $1}')
    bd_h2=$(echo "$bd_upt" | awk '{print $2}')
    bd_m2=$(echo "$bd_upt" | awk '{print $3}')
    bd_s2=$(echo "$bd_upt" | awk '{print $4}')
    boot="${bd_d2}天${bd_h2}时${bd_m2}分${bd_s2}秒"
    [ -z "$bd_d2" ] && boot="-"
    bd=$(uname -v 2>/dev/null | sed 's/#[0-9]* *SMP PREEMPT *//')
    bd_d=$(echo "$bd" | awk '{print $3}')
    bd_m=$(echo "$bd" | awk '{print $2}')
    bd_t=$(echo "$bd" | awk '{print $4}')
    bd_y=$(echo "$bd" | awk '{print $5}')
    case "$bd_m" in Jan) bd_m=01;; Feb) bd_m=02;; Mar) bd_m=03;; Apr) bd_m=04;; May) bd_m=05;; Jun) bd_m=06;; Jul) bd_m=07;; Aug) bd_m=08;; Sep) bd_m=09;; Oct) bd_m=10;; Nov) bd_m=11;; Dec) bd_m=12;; *) bd_m="";; esac
    build="$bd_y-$bd_m-$bd_d $bd_t"; [ -z "$bd_m" ] && build="-"
    now=$(date '+%Y-%m-%d %H:%M:%S')

    printf '{"code":"0","time":"%s","cpu_temp":"%s","wifi":"%s","mhz":"%s","fan":"%s","phy_temp":"%s","load":"%s","mem":"%s","kernel":"%s","arch":"%s","boot":"%s","build":"%s"}' "$now" "$cpu_temp" "$wifi" "$mhz" "$fan_rpm" "$phy_temp" "$load" "$mem" "$kernel" "$arch" "$boot" "$build"
    echo
}
